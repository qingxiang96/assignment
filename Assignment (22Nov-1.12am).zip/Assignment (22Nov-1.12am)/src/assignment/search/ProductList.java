/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.search;

/**
 *
 * @author OEM
 */
public class ProductList<P> implements ProductADT<P> {
    private P[] array;
    private int size;
    
    private String name;
    private String brand;
    private double price;
    private int count =0;

    public ProductList(){
        //Do casting to change type
        array =(P[]) new Object[5];
        
        size = 0;
    }

    /*ProductList(String name, String brand, double price) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
    
    public ProductList(String name, String brand, double price){
        this.name = name;
        this.brand = brand;
        this.price = price;
        count++;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
   /* public void addProduct(P product){
        if(product ! = null){
            if(isFull()){
                expandArray();
            }
            
            array[size] = product;
            size++;
        }
    }*/
    
    private boolean isFull(){
        if(size == array.length){
            return true;
        }
        else{
            return false;
        }
    }
    
    private void expandArray(){
        //assign array address to oldArray
        P[] oldArray = array;
        //create new array with double the size
        array = (P[]) new Object [oldArray.length * 2];
        
        //copy value one by one from oldArray to array
        for(int i = 0 ; i<oldArray.length ; i++){
            array[i] = oldArray[i];
        }
        
        //dereference it because oldArray is no used anymore
        oldArray = null;
    }

    /*public int removeProduct(P product){
        int index = -1;
        
        if(product! = null && !isEmpty()){
            //Use for loop to read product in list one by one
            //use size, x array.length(larger)
        
            for(int i=0 ; i<size ; i++){
                if(array[i].equals(product)){
                    //become null, shift product to move forward 1
                    shiftProducttoLeft(i);
                    size--;
                    index = i;
                }
            }
        }
        return index;
    }*/
    
    private void shiftProducttoLeft(int currentIndex){
        for(int i = currentIndex ; i <size-1 ; i++){
            array[i] = array[i+1];
        }
        array[size-1] = null;
        /*Optional: last item become null since in function remove, the size is 
        decreases 1 so even this line is not write, the value of last item is 
        still store but couldnt be retrieved out
        */
    }
    
    public boolean isEmpty(){
        if (size == 0){
            return true;
        }
        else{
            return false;
        }
    }
    
    public int size(){
        return size;
    }
    
    public String toString(){
        String str = "";
        
        for (int i = 0 ; i < size ; i++){
            str += array[i].toString() + ",";
        }
        return str;
    }

    @Override
    public void addProductPicture(P picture) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String viewProduct(P product) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void selectProduct(P product) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addProduct(P product) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int removeProduct(P product) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }




    
}
