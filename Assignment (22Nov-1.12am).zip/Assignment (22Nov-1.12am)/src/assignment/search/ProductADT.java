/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.search;

/**
 *
 * @author OEM
 */
public interface ProductADT<P> {
    
    public void addProduct(P product);
    /*
    Description     : to add a product to the list
    Precondition    : product is not null
    Postcondition   : product is added to the list
    return          : none
    */
    
    public void addProductPicture(P picture);
    /*
    Description     : to add product picture to the list
    Precondition    : picture is not null
    Postcondition   : product picture is added to the list
    return          : none
    */
    
    public String viewProduct(P product);
    /*
    Description     : to view product name from the list
    Precondition    : product is not null
    Postcondition   : product name showed from the list
    return          : the product name
    */
            
    public int removeProduct(P product);
    /*
    Description     : to remove product from the list
    Precondition    : product is not null
                    : list is not empty
                    : item exists in list
    Postcondition   : product be removed from the list
    return          : if the item exists, return the index of the item else return -1
    */
            
    public void selectProduct(P product);
    /*
    Description     : to select product
    Precondition    : product is not null
    Postcondition   : product be selected
    return          : none
    */
    
    public boolean isEmpty();
    /*
    Description     : to check the product is empty or not
    Precondition    : none
    Postcondition   : none
    return          : if it is empty, else return false
    */
    
    public int size();
    /*
    Description     : to check the size of the list
    Precondition    : none
    Postcondition   : none
    return          : return size of list
    */
            
}
